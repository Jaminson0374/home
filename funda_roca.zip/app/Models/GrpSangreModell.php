<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GrpSangreModell extends Model
{
    protected $table = "grp_sangre";
    use HasFactory;
}
