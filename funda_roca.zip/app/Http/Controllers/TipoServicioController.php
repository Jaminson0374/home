<?php

namespace App\Http\Controllers;

use App\Models\Tiposervicio;
use Illuminate\Http\Request;

class TipoServicioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
       //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Tiposervicio  $tiposervicio
     * @return \Illuminate\Http\Response
     */
    public function show(Tiposervicio $tiposervicio)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Tiposervicio  $tiposervicio
     * @return \Illuminate\Http\Response
     */
    public function edit(Tiposervicio $tiposervicio)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Tiposervicio  $tiposervicio
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Tiposervicio $tiposervicio)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Tiposervicio  $tiposervicio
     * @return \Illuminate\Http\Response
     */
    public function destroy(Tiposervicio $tiposervicio)
    {
        //
    }
}
